from flask import Flask, request, render_template_string
import subprocess

app = Flask(__name__)

html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPAM SMS WEB</title>
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        h2 {
            color: #ffcc00;
        }
        form {
            background-color: #1e1e1e;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.5);
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #333;
            border-radius: 4px;
            background-color: #333;
            color: #fff;
        }
        button {
            background-color: #ffcc00;
            color: #000;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
        }
        button:hover {
            background-color: #e6b800;
        }
        .image-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .image-container img {
            max-width: 300px;
            height: auto;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="image-container">
        <img src="https://i.imgur.com/taqzl6p.jpeg" alt="">
    </div>
    <h2> SPAM SMS FREE ☄️ </h2>
    <h3> https://t.me/Humanpv </h3>
    <form action="/run_script" method="POST">
        <label for="sdt">Phone Number:</label>
        <input type="text" id="sdt" name="sdt" required>
        <label for="count">Repeat Times:</label>
        <input type="number" id="count" name="count" value="5" min="1" required>
        <button type="submit">Attack</button>
    </form>
</body>
</html>
"""

@app.route('/')
def index():
    # Hiển thị form HTML
    return render_template_string(html_template)

@app.route('/run_script', methods=['POST'])
def run_script():
    sdt = request.form.get("sdt")
    count = request.form.get("count", "5")

    # Chạy file dec.py với subprocess
    try:
        result = subprocess.run(["python3", "dec.py", sdt, count], capture_output=True, text=True)
        output = result.stdout
    except Exception as e:
        output = f"An error occurred: {e}"

    # Trả về kết quả cho người dùng
    return f"<h2>Result:</h2><pre>{output}</pre><br><a href='/'>Go back</a>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
