from flask import Flask, jsonify, render_template_string

app = Flask(__name__)

# Load Hotmail addresses from a file
def load_hotmail_addresses(filename="hotmail.txt"):
    with open(filename, "r") as f:
        addresses = f.read().splitlines()
    return addresses

# Load Proxy addresses from a file
def load_proxies(filename="proxies.txt"):
    with open(filename, "r") as f:
        proxies = f.read().splitlines()
    return proxies

# HTML template for the welcome banner
html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to the API</title>
    <style>
        body {{
            background-color: #000; /* Black background */
            color: #fff; /* White text */
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
        }}
        h1 {{
            font-size: 3em;
            margin-bottom: 20px;
            text-shadow: 2px 2px 5px rgba(255, 255, 255, 0.3);
        }}
        h3 {{
            font-size: 1.5em;
            margin-top: 20px;
        }}
        a {{
            color: #1e90ff; /* Bright blue link color */
            text-decoration: none;
            transition: color 0.3s;
        }}
        a:hover {{
            color: #ff6347; /* Change color on hover */
        }}
    </style>
</head>
<body>
    <h1>Welcome to the API!</h1>
    <h3>Get Hotmail Addresses and Proxies</h3>
    <p>Use the following endpoints:</p>
    <p><a href="/api/hotmail">Get Hotmail Addresses</a></p>
    <p><a href="/api/proxies">Get Proxy Addresses</a></p>
</body>
</html>
"""

# Home route
@app.route('/')
def index():
    return render_template_string(html_template)

# API endpoint for Hotmail addresses
@app.route('/api/hotmail', methods=['GET'])
def get_hotmail():
    hotmail_addresses = load_hotmail_addresses()
    # Assuming the format in hotmail.txt is just addresses like example@hotmail.com
    formatted_addresses = [f"{address.split('@')[0]}:password" for address in hotmail_addresses]  # Replace "password" with your logic if needed
    return jsonify({"hotmail": formatted_addresses})

# API endpoint for Proxy addresses
@app.route('/api/proxies', methods=['GET'])
def get_proxies():
    proxies = load_proxies()
    return jsonify({"proxies": proxies})

if __name__ == '__main__':
    app.run(debug=True)
